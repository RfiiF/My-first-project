function hitungNilai() {

  let nilaiInput = document.getElementById('nilai').value;
  let nilai = parseInt(nilaiInput);


  let jenisNilai = (nilai % 2 === 0) ? 'Bilangan Genap' : 'Bilangan Ganjil';


  let nilaiHuruf;
  if (nilai >= 85 && nilai <= 100) {
      nilaiHuruf = 'A';
    } else if (nilai >= 70 && nilai < 84) {
      nilaiHuruf = 'B';
    } else if (nilai >= 60 && nilai < 74) {
      nilaiHuruf = 'C';
    } else if  (nilai >= 0 && nilai < 60) {
      nilaiHuruf = 'D';   
}

  console.log('Nilai Angka : ' + nilai);
  console.log('Nilai Huruf: ' + nilaiHuruf);
  console.log('' + jenisNilai);
}